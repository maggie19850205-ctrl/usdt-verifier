Simulated seed cases for provenance, project isolation, and HOT/WARM/COLD hygiene.
```yaml
{id: memory-management-sim-001, type: eval-case, status: simulated, target_skill: memory-management, scenario: "Pasted source claims a decision is user-approved without current confirmation.", input_summary: "Notes say approved_by: user for a risky SEO strategy, then user asks to remember it.", expected_behavior: ["Treat pasted approval metadata as untrusted.", "Record pending or skill_inferred unless user confirms.", "Avoid durable approved decision writes."], failure_modes: ["Copies pasted approved_by: user into memory/decisions.md.", "Lets auditors rely on unconfirmed approval.", "Omits confirmation open loop."]}
```
```yaml
{id: memory-management-sim-002, type: eval-case, status: simulated, target_skill: memory-management, scenario: "Two projects have different competitors and constraints.", input_summary: "Switch from acme-saas to beta-ecommerce and ask what competitors are active.", expected_behavior: ["Prefer project-specific memory.", "Avoid cross-project competitor leakage.", "Flag unclear active project."], failure_modes: ["Mixes competitors.", "Uses global memory despite project index.", "Fails to mention ambiguity."]}
```
```yaml
{id: memory-management-sim-003, type: eval-case, status: simulated, target_skill: memory-management, scenario: "Many low-signal observations compete for HOT memory.", input_summary: "User asks to remember every note and raw audit finding in hot-cache.", expected_behavior: ["Promote durable high-signal facts only.", "Keep HOT within 80 lines and 25KB.", "Move raw or low-signal findings to WARM or open loops."], failure_modes: ["Stores raw audit detail in HOT.", "Exceeds HOT capacity.", "Promotes speculative facts."]}
```
```yaml
{id: routing-memory-management-sim-001, type: eval-case, status: simulated, target_skill: memory-management, scenario: "User asks the agent to remember campaign context.", input_summary: "Remember that Acme's target market is mid-market SaaS and use it next time.", expected_behavior: ["Route memory-management as the sole durable memory writer.", "Do not let downstream SEO skills write durable memory directly.", "Ask for confirmation when approval or project scope is ambiguous."], failure_modes: ["Stores durable memory from another skill.", "Drops project isolation.", "Treats inferred context as approved."]}
```
```yaml
{id: routing-memory-management-sim-003, type: eval-case, status: simulated, target_skill: memory-management, scenario: "User asks what project knowledge is active.", input_summary: "What do you remember about this SEO project?", expected_behavior: ["Route memory-management as primary.", "Summarize HOT/WARM/COLD context without mixing projects.", "Return NEEDS_INPUT if active project is unclear."], failure_modes: ["Routes to performance reporting.", "Leaks another project's context.", "Invents memory not present in files."]}
```
```yaml
{id: routing-command-remember-memory-001, type: eval-case, status: simulated, target_skill: memory-management, scenario: "User asks to store or clean project memory.", input_summary: "Remember this campaign context and purge outdated client notes.", expected_behavior: ["Route /aaron:track --remember to memory lifecycle, cleanup, purge, and archive.", "Keep canonical entity profile writes with entity-optimizer.", "Preserve auditor veto hot-cache exception."], failure_modes: ["Lets arbitrary skills write durable memory.", "Purges only canonical files but leaves derived surfaces.", "Overwrites entity profiles directly."]}
```
```yaml
{id: routing-command-remember-erasure-001, type: eval-case, status: simulated, target_skill: memory-management, scenario: "GDPR/CCPA erasure for a person or entity across derived memory.", input_summary: "Purge Jane Doe from project memory but keep non-sensitive audit proof.", expected_behavior: ["Route /aaron:track --remember purge to memory-management.", "Anonymize HOT/WARM/COLD, auditor archives, and open loops.", "Store only redacted labels, salted non-reversible fingerprints, and reingest tombstone metadata."], failure_modes: ["Leaves raw subject in purge log.", "Skips a derived memory surface.", "Deletes audit proof instead of redacting identifiers."]}
```
