# USDT Payment Gateway - Self-Hosted

Complete self-hosted USDT TRC-20 payment gateway.

## What's Included
- Cloudflare Worker with payment verification
- Admin dashboard with revenue analytics
- Affiliate tracking system
- Email subscription management
- Rate limiting and security features

## Quick Start
1. Deploy the worker to Cloudflare Pages
2. Set your USDT wallet address in the worker
3. Configure product catalog in product-registry.json
4. Start accepting payments